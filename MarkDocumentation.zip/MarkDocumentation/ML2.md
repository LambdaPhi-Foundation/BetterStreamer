# ML2.md — AI Decision Intelligence, Predictive Networking & Policy Optimization

> **Owner**: ML2 (Machine Learning Engineer 2 — Decision Modeling, Predictive Networking & AI Policy)  
> **Project**: Content-Aware Adaptive Bitrate Streaming (`BetterStreamer`)  
> **Core Stack**: Python, PyTorch, Scikit-Learn, LightGBM, ONNX, Rust Inference (`ort` / `smartcore`)  
> **Document Status**: Authoritative Work Breakdown & Responsibilities Guide  

---

## 1. Executive Summary & Role Mission

As **ML2**, you own the **Decision Intelligence, Predictive Modeling, and AI-Enhanced ABR Policies** of the BetterStreamer project.

While ML1 extracts visual features from raw video, and DC builds the core simulation harness and deterministic heuristic allocator, your mission is to **replace static heuristics with learning-based intelligence**. You design models that predict marginal perceptual quality gains ($\Delta\text{VMAF}/\Delta\text{MB}$), forecast near-future network throughput to avert buffer crashes, learn optimal feature weighting parameters, and deploy lightweight, low-latency models into DC's Rust engine for real-time simulation and evaluation.

---

## 2. Core Responsibilities & Domain Ownership

```
                        ┌──────────────────────────────────────┐
                        │      ML2: AI Decision Intelligence   │
                        │  (Prediction, RL, Policy, Deployment)│
                        └──────────────┬───────────────────────┘
                                       │
            ┌──────────────────────────┴──────────────────────────┐
            │ Trained Models & ONNX Weights                       │ Policy Benchmarks
            ▼                                                     ▼
  ┌──────────────────┐                                  ┌──────────────────┐
  │     DC (Rust)    │                                  │      WB (Web)    │
  │ Embedded Runtime │                                  │ Model Telemetry  │
  └──────────────────┘                                  └──────────────────┘
```

### 2.1 Learning Optimal Feature Weights & Non-Linear Priority (§6 & §11-P8)
- **Heuristic Weight Regressor**:
  - The deterministic baseline uses fixed weights: $\text{Priority} = w_m \cdot \text{Motion} + w_c \cdot \text{Complexity}$.
  - Formulate an optimization/regression pipeline using ML1's dataset to discover optimal $(w_m, w_c)$ that maximize total delivered VMAF under various bandwidth constraints.
- **Non-Linear Perceptual Priority Models**:
  - Train non-linear models (Gradient Boosted Trees, Multi-Layer Perceptrons) that map multi-dimensional feature vectors $(\text{motion}, \text{complexity}, \text{spatial\_energy}, \text{saliency})$ directly to perceptual sensitivity.
  - Mitigate edge-case failures: e.g., static-but-complex scenes (lectures/slides) being starved of bits by naive motion-biased heuristics.

### 2.2 Marginal Perceptual Gain Predictor ($\Delta\text{VMAF} / \Delta\text{MB}$)
- **The Core Machine Learning Target (§6 of Word Doc)**:
  - Formulate the predictive target:
    $$\widehat{\Delta}(c, r) = \mathbb{E}\left[\frac{\text{VMAF}(c, r) - \text{VMAF}(c, r-1)}{\text{SizeMB}(c, r) - \text{SizeMB}(c, r-1)}\right]$$
  - Build a lightweight regression model (e.g., CatBoost or compact MLP) that predicts the marginal gain for each candidate bitrate rung given the chunk's content features.
  - This allows DC's allocator to execute a greedy knapsack algorithm that always allocates bits to chunks yielding the highest human-perceived gain per megabyte.

### 2.3 Predictive Network Bandwidth Modeling
- **Proactive vs Reactive Streaming**:
  - Traditional ABR (Baseline) reacts to throughput drops *after* a chunk download lags, causing buffer starvation.
  - Build a time-series throughput forecasting model:
    $$\widehat{T}_{t+1}, \dots, \widehat{T}_{t+k} = f\left(\{T_{t-i}\}_{i=0}^{N}, \{\text{RTT}_{t-i}\}_{i=0}^{N}, \text{buffer\_state}\right)$$
  - Model options: Lightweight 1D-CNN / Temporal Convolutional Network (TCN), GRU, or Autoregressive Holt-Winters filter.
  - Specialize in **early cliff detection**: identifying sudden bandwidth drops (e.g., cellular handoff, tunnel ingress) before the playback buffer empties.

### 2.4 Learned Adaptive Bitrate (AI-ABR) Policy
- **Reinforcement Learning / Contextual Bandit Formulation**:
  - Design a learned decision agent selecting chunk rungs $r_t \in \{0, 1, 2, 3, 4\}$.
  - **State Vector $S_t$**:
    $$S_t = \left[\text{BufferLevel}_t, \text{PastThroughput}, \text{ChunkFeatures}(c_t), \text{CandidateSizes}, \text{RemainingTime}\right]$$
  - **Comprehensive Reward Function**:
    $$\mathcal{R}_t = \text{VMAF}(c_t, r_t) - \alpha \cdot \text{RebufferTime}_t - \beta \cdot |\text{VMAF}(c_t, r_t) - \text{VMAF}(c_{t-1}, r_{t-1})| - \gamma \cdot \text{BitrateWaste}$$
  - Optimize the trade-off between maximizing visual quality, preventing rebuffering stalls, and avoiding jarring quality oscillations.

### 2.5 Personalization & Viewer Preference Modeling (Extension)
- Model viewer sensitivity profiles:
  - *Smoothness-Sensitive Profile*: Heavy penalty on resolution shifts and rebuffering; prioritizes stable medium-quality streams.
  - *Quality-Sensitive Profile*: Heavy penalty on blur/compression artifacts in complex scenes; accepts minor buffer risk for peak 1080p clarity.
  - *Device-Specific Profile*: Mobile screen (spatial complexity less noticeable) vs 4K TV (compression artifacts highly visible).

### 2.6 Model Export, Rust Inference & Latency Budget
- **Export Pipeline**:
  - Export trained PyTorch / Scikit-learn models to **ONNX** format or extract compact weight matrices.
- **Rust Integration**:
  - Coordinate with DC to embed inference into the simulation loop using `ort` (ONNX Runtime Rust), `burn`, or direct linear-algebra matrix multiplication.
- **Latency Budget Constraint**:
  - Inference **must execute in under 1.0 ms per chunk** to avoid stalling the simulation loop or client player. Keep models compact and quantized (INT8 / FP16).

---

## 3. Key Deliverables & Artifacts

1. **`models/`**:
   - `marginal_vmaf_predictor.onnx`: Model predicting $\Delta\text{VMAF}/\Delta\text{MB}$ per rung.
   - `bandwidth_forecaster.onnx`: Time-series network predictor for proactive rate adaptation.
   - `learned_weights.json`: Empirically optimized $(w_m, w_c)$ coefficients across video genres.
2. **`scripts/training/`**:
   - `train_marginal_gain.py`: Training script for marginal rate-distortion gain.
   - `train_throughput_predictor.py`: Network time-series forecasting training pipeline.
   - `evaluate_policy.py`: Benchmark evaluation script comparing Heuristic vs ML vs Baseline.
3. **`tests/model_validation/`**:
   - Hold-out test suite verifying prediction accuracy ($R^2 > 0.85$ on unseen test videos).

---

## 4. Cross-Team Technical Interfaces & Contracts

### 4.1 Interface to ML1 (Feature Input)
- **Data Ingestion**: Consume the tabular datasets generated by ML1 (`features.csv` / `vmaf_matrix.json`).
- **Feature Normalization**: Agree on standard scaling (Z-score or MinMax normalization) to ensure training distributions match live extraction values.

### 4.2 Interface to DC (Rust Engine Deployment)
- **Policy Trait Conformance**:
  - Provide model weights and inference functions that implement DC's `AbrPolicy` trait:
    ```rust
    pub struct MlPerceptualAbr {
        session: ort::Session,
        lookahead_chunks: usize,
    }
    impl AbrPolicy for MlPerceptualAbr {
        fn select(&mut self, ctx: &PlayerCtx, segment: &Segment) -> RepresentationId {
            // Evaluates ONNX model and returns chosen rung ID
        }
    }
    ```
- **Fallback Guarantee**: Ensure the model gracefully falls back to DC's deterministic heuristic if inference fails or encounters out-of-distribution inputs.

### 4.3 Interface to WB (Web Platform Visualization)
- Provide model explanation telemetry:
  - Feature importances (SHAP / attention weights) for why a chunk was prioritized.
  - Predicted throughput curves for WB's live chart overlay.
  - Model confidence and decision breakdown.

---

## 5. Tools, Tech Stack & Environment

- **Python 3.11+**: `torch`, `scikit-learn`, `lightgbm`, `xgboost`, `pandas`, `numpy`.
- **Time-Series / RL**: `statsmodels`, `stable-baselines3` (if exploring PPO/DQN ABR).
- **Model Deployment**: `onnx`, `onnxruntime`, `onnxruntime-gpu` (for training), `ort` (Rust bindings).
- **Analysis**: `jupyterlab`, `matplotlib`, `seaborn`.

---

## 6. Execution Roadmap & Milestones

- **Milestone 1 (Dataset Exploration & Baselines)**: Ingest ML1's dataset. Establish baseline $R^2$ using simple linear regression for $\Delta\text{VMAF}/\Delta\text{MB}$.
- **Milestone 2 (Weight Optimization)**: Run systematic grid search and Bayesian optimization to identify optimal deterministic weights $(w_m, w_c)$ across the 5 video genres.
- **Milestone 3 (Marginal Gain Model)**: Train CatBoost / MLP predictor for marginal quality gain. Export to ONNX. Verify inference time $< 1 \text{ ms}$.
- **Milestone 4 (Throughput Predictor)**: Train time-series model on trace profiles (`traces/*.csv`). Demonstrate proactive adaptation to sudden bandwidth drops.
- **Milestone 5 (Rust Integration & Benchmark)**: Integrate ONNX model into DC's simulation harness in Phase 8. Measure VMAF/MB gains over the heuristic policy.

---

## 7. Verification & Acceptance Criteria

1. **Prediction Accuracy**: The marginal gain predictor must achieve $R^2 \ge 0.82$ on unseen hold-out clips.
2. **Inference Latency**: Single-chunk prediction latency must benchmark under $1.0\text{ ms}$ on standard CPU.
3. **Comparative Superiority (§11-P8)**: In end-to-end simulation across standard traces, the ML-enhanced policy must match or exceed the heuristic policy's Quality/MB metric with **zero rebuffering regressions**.
4. **Deterministic Reproducibility**: Given fixed inputs, ONNX model inference must return deterministic, repeatable outputs across repeated runs.
