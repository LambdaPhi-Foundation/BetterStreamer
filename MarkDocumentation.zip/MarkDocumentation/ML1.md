# ML1.md — AI-Based Content Assessment & Visual Feature Intelligence

> **Owner**: ML1 (Machine Learning Engineer 1 — Visual Feature Intelligence & Ground Truth)  
> **Project**: Content-Aware Adaptive Bitrate Streaming (`BetterStreamer`)  
> **Core Stack**: Python, OpenCV, FFmpeg, libvmaf, PyAV, NumPy, SciPy  
> **Document Status**: Authoritative Work Breakdown & Responsibilities Guide  

---

## 1. Executive Summary & Role Mission

As **ML1**, you own the **Computer Vision, Video Processing, and Perceptual Ground Truth** pipeline of the BetterStreamer project. 

The core thesis of the project states that traditional ABR is blind to visual dynamics, treating every video chunk as equally visually demanding. Your mission is to provide the **content awareness**: you extract quantitative motion and spatial complexity metrics from raw video frames, curate the benchmark test video dataset, encode multi-bitrate ladders, and compute ground-truth perceptual quality scores (VMAF and SSIM). The feature vectors and rate-distortion profiles you generate feed directly into DC's Rust simulation engine and ML2's predictive decision models.

---

## 2. Core Responsibilities & Domain Ownership

```
                       ┌───────────────────────────────┐
                       │     ML1: Video & Vision CI    │
                       └──────────────┬────────────────┘
                                      │
            ┌─────────────────────────┼─────────────────────────┐
            │ Raw Feature Vectors     │ Transcoded Media        │ VMAF/SSIM Ground Truth
            ▼                         ▼                         ▼
  ┌──────────────────┐      ┌──────────────────┐      ┌──────────────────┐
  │   DC (Rust)      │      │    WB (Web UI)   │      │   ML2 (Models)   │
  │ Ingestion Engine │      │ Player Chunks    │      │ Policy Training  │
  └──────────────────┘      └──────────────────┘      └──────────────────┘
```

### 2.1 Video Corpus Curation (§9.1 of Project Specification)
You are responsible for curating and standardizing the benchmark video corpus representing the 5 mandatory categories:
1. **Talking Head / Low Dynamics**: Interviews, video podcasts, newscasts (low motion, high facial salience, static background).
2. **Sports / High Dynamics**: Football, basketball, racing (rapid object movement, camera pans, high frame-to-frame difference).
3. **Action / Heavy Camera Motion**: Drone footage, fast-paced cinematic cuts, handheld camera motion (high motion entropy).
4. **Text / Screen Capture / Lecture**: Presentation slides, coding screencasts, technical diagrams (sharp high-frequency edges, static blocks).
5. **Mixed-Complexity Footage**: Multi-scene sequence transitioning between static interviews, b-roll landscapes, and rapid action.

*Requirements*: All videos must be normalized to standard reference formats (e.g., 1080p, 30fps/60fps, YUV420p / raw MP4) with known duration and constant frame rate.

### 2.2 Transcoding Ladder & Video Chunking Pipeline
- **Chunking Pipeline**:
  - Implement an automated script to split raw source videos into independent, keyframe-aligned segments (default: **4.0 seconds per chunk**).
  - Enforce closed GOPs (`-g 120 -keyint_min 120 -sc_threshold 0` for 30fps) so every chunk can be decoded independently.
- **Multi-Bitrate Representation Ladder**:
  - Encode each chunk across the standard BetterStreamer bitrate ladder:
    - Rung 0: 360p @ 400 kbps
    - Rung 1: 480p @ 800 kbps
    - Rung 2: 720p @ 1500 kbps
    - Rung 3: 1080p @ 3000 kbps
    - Rung 4: 1080p @ 6000 kbps
  - Use H.264 (`libx264`) with 2-pass rate control to ensure exact bitrate conformity.

### 2.3 Computer Vision Feature Extraction (`analysis/`)
Extract chunk-level features and normalize them to a bounded continuous score in the range $[0.0, 1.0]$:

#### A. Motion Analysis (`motion_score`)
- **Mean Squared Frame Difference (MSFD)**:
  $$\text{MSFD} = \frac{1}{T \cdot W \cdot H} \sum_{t=1}^{T} \sum_{x,y} \left(I_{t}(x,y) - I_{t-1}(x,y)\right)^2$$
- **Motion Vector Extraction**: Extract motion vectors directly from H.264 macroblocks using PyAV/FFmpeg for low-overhead motion velocity estimation.
- **Temporal Gradient / Optical Flow**: Calculate dense optical flow (Farnebäck method) on downscaled luminance channels to capture direction and magnitude variance.

#### B. Spatial Complexity Analysis (`complexity_score`)
- **Spatial Energy & Gradient Magnitude**: Sobel / Scharr gradient operators measuring edge sharpness and detail density.
- **Laplacian Variance**: Measure of spatial frequency variance and texture sharpness:
  $$\sigma^2_{\text{Laplacian}} = \text{Var}\left(\nabla^2 I\right)$$
- **High-Frequency DCT Energy**: 2D Discrete Cosine Transform measuring the ratio of high-frequency energy to total energy across $8 \times 8$ blocks.
- **Texture Entropy**: Shannon entropy of grayscale pixel distribution across frames.

#### C. Saliency & Perceptual Importance (Advanced Extension)
- Detect regions of interest (faces via Haar/RetinaFace, text regions via CRAFT/contour analysis).
- Weight spatial complexity higher when high-detail areas coincide with visual attention zones.

### 2.4 Ground Truth Perceptual Measurement (VMAF & SSIM)
- **Automated VMAF Pipeline**:
  - Build a batch pipeline using `ffmpeg -i degraded.mp4 -i reference.mp4 -lavfi libvmaf` to compute per-frame and per-chunk VMAF scores (0–100 scale).
  - Compute harmonic mean and arithmetic mean VMAF per chunk across all 5 ladder rungs.
- **Structural Similarity (SSIM)**:
  - Calculate frame-by-frame SSIM scores as a supporting objective quality metric.
- **Rate-Distortion (R-D) Curve Generation**:
  - Compute chunk-level rate-distortion curves: $\text{VMAF}(c, \text{bitrate})$.
  - Quantify the marginal perceptual gain:
    $$\frac{\Delta \text{VMAF}}{\Delta \text{MB}} = \frac{\text{VMAF}(c, R_{k+1}) - \text{VMAF}(c, R_k)}{\text{Size}(c, R_{k+1}) - \text{Size}(c, R_k)}$$
  - Empirically verify the core hypothesis: show that for low-complexity chunks, VMAF saturates at low rungs (e.g., 800 kbps), while high-complexity chunks show steep gains up to 6000 kbps.

---

## 3. Key Deliverables & Artifacts

1. **`scripts/pipeline/`**:
   - `chunk_and_encode.py`: Automated multi-rung chunk encoder using FFmpeg.
   - `extract_features.py`: Computes normalized motion and complexity scores per chunk.
   - `compute_vmaf.py`: Automates VMAF/SSIM calculation against reference clips.
2. **`media/manifests/`**:
   - Standard JSON manifests containing chunk descriptors, feature scores, and VMAF lookup tables (e.g., `media/manifests/sports_dynamic_01.json`).
3. **`media/raw_chunks/`**:
   - Encoded `.mp4` / `.ts` video chunks ready for WB web playback and local testing.
4. **Research Analysis Report**:
   - Rate-distortion curves and feature-correlation plots demonstrating that visual features correlate with VMAF requirements across the 5 video genres.

---

## 4. Cross-Team Technical Interfaces & Contracts

### 4.1 Interface to DC (Rust Engine)
- **Feature Export Format**: ML1 produces JSON and CSV files formatted specifically for DC's `src/media.rs` and `src/network.rs` parsers:
  ```json
  {
    "video_id": "lecture_text_01",
    "genre": "text_lecture",
    "segment_duration_s": 4.0,
    "segments": [
      {
        "id": 0,
        "features": {
          "motion": 0.08,
          "complexity": 0.89,
          "priority_heuristic": 0.49
        },
        "vmaf_scores": [78.2, 89.4, 95.1, 98.0, 99.1],
        "sizes_bytes": [200000, 400000, 750000, 1500000, 3000000]
      }
    ]
  }
  ```
- **Pure Algorithm Signatures**: ML1 assists DC in verifying that the pure Rust functions in `src/analysis/motion.rs` and `src/analysis/complexity.rs` mathematically mirror the Python/OpenCV reference implementations.

### 4.2 Interface to ML2 (Decision Intelligence)
- **Training Data Hand-Off**: Provide ML2 with tabular datasets containing:
  $$\left[\text{chunk\_id}, \text{genre}, \text{motion}, \text{complexity}, \text{saliency}, \text{rung\_id}, \text{bitrate}, \text{VMAF}, \text{SSIM}, \Delta\text{VMAF}/\Delta\text{MB}\right]$$
- This dataset is the training substrate ML2 uses to fit regression models, neural predictors, and RL policies.

### 4.3 Interface to WB (Web Platform)
- Provide WB with the folder of transcoded chunk files (`.mp4` / `.m4s`) and HLS playlist manifests (`.m3u8`) so the web player can actually stream and display the clips in the browser.

---

## 5. Tools, Tech Stack & Environment

- **Python 3.11+**: `numpy`, `scipy`, `pandas`, `opencv-python`, `scikit-image`, `av` (PyAV).
- **Video Toolchain**: `ffmpeg` (compiled with `--enable-libvmaf`, `--enable-libx264`).
- **Quality Assessment**: `libvmaf` v3.0+, `vmaf` Python package.
- **Visualization**: `matplotlib`, `seaborn` for rate-distortion curve plots.

---

## 6. Execution Roadmap & Milestones

- **Milestone 1 (Corpus & Chunking)**: Curate 5 reference video clips (1 per genre). Implement `chunk_and_encode.py` to produce 4-second chunks across 5 bitrate rungs.
- **Milestone 2 (Feature Extraction)**: Implement `extract_features.py`. Validate that motion scores range from ~0.05 (static talking head) to ~0.95 (fast sports) and complexity scores capture edge density accurately.
- **Milestone 3 (VMAF Ground Truth)**: Run full VMAF matrix for all clips and representations. Generate complete VMAF lookup tables.
- **Milestone 4 (Integration & Delivery)**: Export standardized JSON manifests to `media/` directory in the repository. Verify that DC's Rust unit tests cleanly parse and validate the dataset.
- **Milestone 5 (Feature Refinement)**: Explore spatial-temporal saliency and face-weighting to enhance priority score sensitivity.

---

## 7. Verification & Acceptance Criteria

1. **Zero NaN / Bounded Scores**: All extracted `motion_score` and `complexity_score` values must strictly satisfy $0.0 \le s \le 1.0$.
2. **Independent Chunk Decodability**: Every generated video chunk must start with an IDR-frame and decode cleanly in isolation via `ffmpeg -v error -i chunk.mp4 -f null -`.
3. **Monotonic Bitrate Verification**: For every chunk, file size must strictly increase monotonically across the 5 rungs ($S_0 < S_1 < S_2 < S_3 < S_4$).
4. **VMAF Ground Truth Completeness**: 100% of video chunks must have verified VMAF scores against the uncompressed source with no missing frames.
